import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class SpringMain {
 
    public static void main(String[] args) {
        //Get the Spring Context
    	Resource r=new ClassPathResource("applicationConfig.xml");  
        BeanFactory ctx=new XmlBeanFactory(r);  
          
         
        //Get the EmployeeDAO Bean//DMDS
        EmployeeDAO employeeDAO = (EmployeeDAO) ctx.getBean("employeeDAO");
         
        //Run some tests for JDBC CRUD operations
//		
	 Employee employee = new Employee(); //uncomment below stuff if you want code for
		 // inserting the data into a table 
		  int rand = new Random().nextInt(1000);
		  employee.setId(rand); 
		  employee.setName("sandeep"); 
		  employee.setRole("developer");
		  employeeDAO.save(employee);
		 
         
//        Read
       Employee emp1 = employeeDAO.getById(679);
        System.out.println("Employee Retrieved::"+emp1);
//        
       //Update
		
		
		 Employee emp = new Employee();
		 emp.setId(679);
		 emp.setRole("hr");
		 emp.setName("mahesh"); 
		 employeeDAO.update(emp);
//		 
		    Employee emp2 = employeeDAO.getById(679);
	        System.out.println("Employee Retrieved::"+emp2);
//		 //JdbcTemplate
        
       //Get All
		
		  List<Employee> empList = employeeDAO.getAll(); 
		  System.out.println(empList);
		 
         
        //Delete
    employeeDAO.deleteById(679);
         
        //Close Spring Context
        //ctx.close();
         
        System.out.println("DONE");
    }
 
}